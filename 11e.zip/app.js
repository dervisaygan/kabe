const puppeteer = require('puppeteer-extra')
const { executablePath } = require('puppeteer')
const StealthPlugin = require('puppeteer-extra-plugin-stealth')
puppeteer.use(StealthPlugin())
const express = require('express')
const app = express()

app.get('/', (req, res) => {
  res.send({ title: 'Başarılı!' })
})


var time = 0
var pages = 0
var page1 = null
const zfc = async () => {
  const browser = await puppeteer.launch({
    args: [
      '--disable-gpu',
      '--disable-dev-shm-usage',
      '--disable-setuid-sandbox',
      '--no-first-run',
      '--no-sandbox',
      '--no-zygote',
      '--single-process',
    ],
    executablePath: executablePath()
  });
  const page = await browser.newPage();
  await page.goto('https://onlinesaat.web.tr/kronometre/#');
  await page.click('#btn-resume');
  page1 = page
}
zfc()

setInterval(() => {
  time++
  setInterval(async () => {
    if (page1 != null) {
      const links = await page1.evaluate(() => {
        var m = document.querySelector('#pnl-time').textContent
        return m
      });
      pages = links
    }
  }, 1000);
}, 1000);



app.get('/zfc', async (req, res) => {

  res.send({
    time: time,
    pages: pages
  })
})


app.listen(80)

